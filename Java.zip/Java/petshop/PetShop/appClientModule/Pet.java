public class Pet {
	String nome;
private	int fome;

public int getFome() {
	return fome;
}
public void setFome(int fome) {
	this.fome = fome;
}
	
}