public class Cachorro {
	String raça;
	String tamanho;
	int idade;
	String cor;


public String alimentar(int fome) {
	String faminto = "O cachorro está sem fome" ;
	String satisfeito = "O cachorro está com fome";
	
	if (fome > 10)
	return faminto;
	else;
	return satisfeito;
		
}
}