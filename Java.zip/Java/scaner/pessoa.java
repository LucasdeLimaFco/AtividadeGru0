public class pessoa {
    private String nome;

        public void setNome(String nome) {
            if (!nome.isEmpty()) { 
            this.nome = nome;
            } 
            else {
            System.out.println("O nome não pode ser vazio!");
            }
    }
    private int idade;

        public void setIdade(int idade) {
        if (idade > 0 && idade <= 120) {
            this.idade = idade;
        } else {
            System.out.println("Idade inválida!");
        }
    }
    public String getNome() {
        return this.nome;
    }

    public int getIdade() {
        return this.idade;
    }
}