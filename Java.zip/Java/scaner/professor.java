public class professor extends pessoa {
    private String disciplina;

        public void setDisciplina(String disciplina){
            if (!disciplina.isEmpty()) { 
                this.disciplina = disciplina;
            } else {
                System.out.println("É nescessário ao uma matéria ");
            }
        }
        public String getDisciplina() {
            return this.disciplina;
            }
}