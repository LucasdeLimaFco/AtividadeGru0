import { StyleSheet, Text, View } from 'react-native';

import { Card } from 'react-native-paper';

import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Silvio
      </Text>
      <Text style={styles.paragraph2}>
        lmao
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 128,  
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: '#111111',
    color: '#FFFFFF',
  },
  paragraph2: {
    margin: 20,
    fontSize: 50,
    fontWeight: '300', 
    textAlign: 'right',
    color: '#9CFF76',
    backgroundColor: '#834343',
    fontFamily: 'monospace', 
  },
});
