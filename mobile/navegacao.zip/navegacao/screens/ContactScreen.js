import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function AboutScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Contato</Text>
      
      <Text style={styles.text}>
        Este Vamos conversar? Ficou com alguma dúvida ou quer fazer um orçamento? Nossa equipe está pronta para te atender pelos nossos canais oficiais.
      </Text>

      {/* Container que agrupa os botões lado a lado */}
      <View style={styles.buttonGroup}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Services')}
        >
          <Text style={styles.buttonText}>⬅️ Voltar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Final')}
        >
          <Text style={styles.buttonText}>Próximo ➡️</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E6FFFF',
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#007375',
  },
  text: {
    marginVertical: 20,
    textAlign: 'center',
    fontSize: 16,
    color: '#444',
  },
  buttonGroup: {
    flexDirection: 'row', // Alinha os filhos horizontalmente
    justifyContent: 'center', // Centraliza o grupo na tela
    gap: 15, // Cria um espaçamento de 15px entre os botões
    marginTop: 10,
  },
  button: {
    backgroundColor: '#00CED1',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    elevation: 3, // Adiciona uma sombrinha no Android
    shadowColor: '#000', // Sombra no iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});