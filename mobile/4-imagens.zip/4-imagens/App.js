import { StyleSheet, ScrollView, Image } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

export default function App() {
  return ( 
     <ScrollView contentContainerStyle={styles.container1}>
      <Card style={styles.card}>
      <Image source={{uri: 'https://static.wikia.nocookie.net/b__/images/5/5e/OceanObynPortrait.png/revision/latest?cb=20190612024250&path-prefix=bloons'}} style={styles.imagens} />
      </Card>

      <Card style={styles.card}>
        <Image source={{uri: 'https://assetsio.gnwcdn.com/pokemon-legends-arceus-lendarios-miticos-1643379409453.jpg?width=1200&height=900&fit=crop&quality=100&format=png&enable=upscale&auto=webp'}} style={styles.imagens} />
      </Card>
      
      <Card style={styles.card}>
        <Image source={{uri: 'https://i.ytimg.com/vi/3OwedZj7Fso/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLDhyHMuCHQfVDkJvZAqIG0_WzEozQ'}} style={styles.imagens} />
      </Card>

      <Card style={styles.card}>
        <Image source={{uri: 'https://admin.cnnbrasil.com.br/wp-content/uploads/sites/12/2026/01/remo-yagopikachu-e1767267662458.jpeg?w=1024'}} style={styles.imagens} />
      </Card>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container1: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'spaceBetween',
  },
  card: {
    width: '48%',
  },
  imagens: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  }
});