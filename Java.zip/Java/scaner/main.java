import java.util.Scanner;

public class main {
    public static void main (String[] args) {
        Scanner leitor = new Scanner(System.in);

      
        aluno objAluno = null; 
        professor objProfessor = null;

        int opcao;

        do {
           
            System.out.println("--- MENU DO SISTEMA ---");
            System.out.println("1 - Cadastrar Aluno");
            System.out.println("2 - Cadastrar Professor");
            System.out.println("3 - Exibir Aluno");
            System.out.println("4 - Exibir Professor");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = leitor.nextInt();
            leitor.nextLine(); 

            switch (opcao) {
                case 1:
            
                    objAluno = new aluno(); 

                    System.out.println("--- Cadastro de Aluno ---");

                    System.out.print("Digite o nome: ");
                    String nomea = leitor.nextLine();
                    objAluno.setNome(nomea);

                  
                    System.out.print("Digite a idade: ");
                    int idadea = leitor.nextInt();
                    leitor.nextLine();
                    objAluno.setIdade(idadea);

                    System.out.print("Digite a matrícula: ");
                    String matricula = leitor.nextLine();
                    objAluno.setMatricula(matricula);

                    System.out.println("Aluno cadastrado com sucesso!");

                    System.out.println("Pressione ENTER para continuar...");
                    leitor.nextLine();

                    break;
                case 2:

                    objProfessor = new professor(); 

                    System.out.println("--- Cadastro de Professor ---");

                    System.out.print("Digite o nome: ");
                    String nomep = leitor.nextLine();
                    objProfessor.setNome(nomep);

                  
                    System.out.print("Digite a idade: ");
                    int idadep = leitor.nextInt();
                    leitor.nextLine();
                    objProfessor.setIdade(idadep);

                    System.out.print("Digite a matrícula: ");
                    String disc = leitor.nextLine();
                    objProfessor.setDisciplina(disc);

                    System.out.println("Professor cadastrado com sucesso!");
           
                    System.out.println("Pressione ENTER para continuar...");
                    leitor.nextLine();
                    break;
               case 3:
                if (objAluno != null) {
                    System.out.println("\n--- DADOS DO ALUNO ---");
                    System.out.println("Nome: " + objAluno.getNome());
                    System.out.println("Idade: " + objAluno.getIdade());
                    System.out.println("Matrícula: " + objAluno.getMatricula());
                    System.out.println("----------------------");
                } else {

                 System.out.println("\n[!] Erro: Nenhum aluno cadastrado!");
                }

 
                System.out.println("\nPressione ENTER para voltar ao menu...");
                leitor.nextLine(); 
                break;
                case 4:
                if (objProfessor != null) {
                    System.out.println("\n--- DADOS DO Professor ---");
                    System.out.println("Nome: " + objProfessor.getNome());
                    System.out.println("Idade: " + objProfessor.getIdade());
                    System.out.println("Matrícula: " + objProfessor.getDisciplina());
                    System.out.println("----------------------");
                } else {

                 System.out.println("\n[!] Erro: Nenhum professor cadastrado!");
                }

 
                System.out.println("\nPressione ENTER para voltar ao menu...");
                leitor.nextLine(); 
                break;
                case 0:
                    System.out.println("Saindo...");
                    break;
               default:
                System.out.println("\n[!] ERRO: Opção '" + opcao + "' é inválida!");
                System.out.println("Escolha apenas entre 0, 1, 2, 3 ou 4.");
                System.out.print("Pressione ENTER para voltar ao menu...");
                leitor.nextLine(); // Se ele pular este, coloque outro logo abaixo
                break;
    }
        } while (opcao != 0);
        
        System.out.println("Sistema encerrado.");
    }
}