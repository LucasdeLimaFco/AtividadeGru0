import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function AboutScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sobre</Text>
      
      <Text style={styles.text}>
        Este Nossa Missão Este aplicativo foi desenvolvido para mostrar como a tecnologia pode ser simples e eficiente. Nosso objetivo é proporcionar uma experiência de navegação fluida e intuitiva para todos os usuários.
      </Text>

      {/* Container que agrupa os botões lado a lado */}
      <View style={styles.buttonGroup}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.buttonText}>⬅️ Voltar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Services')}
        >
          <Text style={styles.buttonText}>Próximo ➡️</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  text: {
    marginVertical: 20,
    textAlign: 'center',
    fontSize: 16,
    color: '#444',
  },
  buttonGroup: {
    flexDirection: 'row', // Alinha os filhos horizontalmente
    justifyContent: 'center', // Centraliza o grupo na tela
    gap: 15, // Cria um espaçamento de 15px entre os botões
    marginTop: 10,
  },
  button: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    elevation: 3, // Adiciona uma sombrinha no Android
    shadowColor: '#000', // Sombra no iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});