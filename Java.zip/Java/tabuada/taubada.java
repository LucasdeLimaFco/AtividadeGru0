
import java.util.Scanner;

public class taubada {
	  public static void main(String[] args) {
		    Scanner valor = new Scanner(System.in);
		    int n;
		    
		    System.out.println("Digite um valor: ");
		    n = valor.nextInt();   
		       
		    System.out.println("Tabuada do " + n);        
		    
		    for (int i = n; i <= n + 10; i++) {
			      for (int j = 1; j <= 10; j++) {
			        System.out.print(i * j + " ");
			      }
			      System.out.println();
			    }
		    valor.close();
			  }  
	  }