public class aluno extends pessoa {
    private String matricula;

     public void setMatricula(String matricula){
            if (!matricula.isEmpty()) { 
                this.matricula = matricula;
            } else {
                System.out.println("É nescessário uma matricula");
            }
        }
        public String getMatricula() {
            return this.matricula;
            }
}