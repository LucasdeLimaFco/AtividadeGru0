import React from 'react';
import { View, Text, SafeAreaView } from 'react-native';

export default function AboutScreen() {
  return (
    <SafeAreaView>
      <View>
        <Text>Página Básica</Text>
        <Text>Este é um exemplo sem estilização (CSS-in-JS).</Text>
      </View>
    </SafeAreaView>
  );
}