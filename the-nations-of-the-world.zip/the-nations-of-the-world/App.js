import { StyleSheet, Text, View, Image, TouchableOpacity, Button, Modal } from 'react-native';
import  { Card } from 'react-native-paper';
import { useState } from 'react';

export default function App() {

  const [imagemSelecionada, setImagemSelecionada] = useState(null);
  const abrirModal = (url) => {
    setImagemSelecionada(url);
  };

  return (
    <View style={styles.container}>

      <TouchableOpacity onPress={() =>abrirModal('https://www.flagcolorcodes.com/data/flag-of-real-madrid-cf.png')}>
      <Image
        source={{ uri: 'https://www.flagcolorcodes.com/data/flag-of-real-madrid-cf.png' }}
        style={{ width: 150, height: 90 }}
      />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => abrirModal('https://www.flagcolorcodes.com/data/flag-of-real-madrid-cf.png')}>
      <Image
        source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Flag_of_Grenada.svg/1280px-Flag_of_Grenada.svg.png' }}
        style={{ width: 150, height: 90 }}
      />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => abrirModal('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT19JKqVO5v5QZqfj2H2KgkAjo5dzblhosyYA&s')}>
      <Image
        source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT19JKqVO5v5QZqfj2H2KgkAjo5dzblhosyYA&s' }}
        style={{ width: 150, height: 90 }}
      />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => abrirModal('https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Flag_of_Morocco.svg/3840px-Flag_of_Morocco.svg.png')}>
      <Image
        source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Flag_of_Morocco.svg/3840px-Flag_of_Morocco.svg.png' }}
        style={{ width: 150, height: 90 }}
      />
      </TouchableOpacity>
      <Modal
        visible={imagemSelecionada !== null} 
        animationType="slide"
        transparent={true}
        onRequestClose={() => setImagemSelecionada(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            
            <Image
              source={{ uri: imagemSelecionada }}
              style={{ width: 320, height: 190 }}
              resizeMode="contain"
            />

            <View style={{ marginTop: 20 }}>
              <Button
                title="Fechar"
                color="red"
                onPress={() => setImagemSelecionada(null)}
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#AAB6F0',
    gap: 15
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center'
  }
});
