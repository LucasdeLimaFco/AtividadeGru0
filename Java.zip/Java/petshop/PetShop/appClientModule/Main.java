
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pet cachorro = new Pet ();
		cachorro.nome = "Pitoco";
		cachorro.setFome(17);
		
		Cachorro canino = new Cachorro ();
		canino.raça = "Pincher";
		canino.tamanho = "Pequeno";
		canino.idade = 3;
		canino.cor = "Preto";
		
		String gula = canino.alimentar(cachorro.getFome());
		
		System.out.println(cachorro.nome);
		System.out.println(cachorro.getFome());
		System.out.println(canino.raça);
		System.out.println(canino.tamanho);
		System.out.println(canino.idade);
		System.out.println(canino.cor);
		System.out.println(gula);
		
		
		
	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

}